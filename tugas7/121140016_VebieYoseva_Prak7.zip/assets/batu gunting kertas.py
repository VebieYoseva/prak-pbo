import random
import tkinter as tk
from tkinter import *
from tkinter import messagebox

root = tk.Tk()
root.title("BATU GUNTING KERTAS")

player_score = 0
rival_score = 0

def Game():

    player_choice = player_choice_var.get()
    rival_choice = random.choice(["Batu", "Gunting", "Kertas"])

    global player_score, rival_score
    if player_choice == rival_choice:
        result_var.set("Seri!")
    elif player_choice == "Kertas" and rival_choice == "Batu":
        result_var.set("Kamu menang!")
        player_score += 1
    elif player_choice == "Batu" and rival_choice == "Gunting":
        result_var.set("Kamu menang!")
        player_score += 1
    elif player_choice == "Batu" and rival_choice == "Gunting":
        result_var.set("Kamu menang!")
        player_score += 1
    else:
        result_var.set("Lawan menang!")
        rival_score += 1

    player_score_var.set(f"Kamu: {player_score}")
    rival_score_var.set(f"Lawan: {rival_score}")

root. geometry('925x500+300+200')
root.configure(bg="#20B2AA")
root.resizable(False, False)

img = PhotoImage(file='C:/Users/akuna/OneDrive/Documents/prakpbo/gambar.png')
Label(root,width=925, height= 500, image = img, bg = "#20B2AA" ).place(x=300, y=10)

img1 = PhotoImage(file='C:/Users/akuna/OneDrive/Documents/prakpbo/gambar1.png')
Label(root,width=150, height= 500, image = img1, bg = "#20B2AA").place(x=90, y=10)

heading = tk.Label(root, text = " SELAMAT DATANG DIPERMAINAN \n BATU/GUNTING/KERTAS", bg= "#20B2AA", fg = "black", font=('Times New Roman', 18, 'bold'))
heading.place(x=250, y=10)

player_label = tk.Label(root, text= "Ambil pilihanmu:", fg = "black",bg= "#20B2AA", font=("Times New Roman", 14, 'bold'))
player_label.place(x=400, y=90)


player_choice_var = tk.StringVar()
player_choice_var.set("Batu")

batu_button = tk.Button(root,width=37, pady=7, text = "BATU", command=lambda: Game("Batu"), bg='#FFD700', fg = 'black', border=0, font=("Times New Roman", 12, 'bold')).place(x=300, y=150)

gunting_button = tk.Button(root,width=37, pady=7, text = "GUNTING", command=lambda: Game("Gunting"), bg='#FFD700', fg = 'black', border=0, font=("Times New Roman", 12, 'bold')).place(x=300, y=200)

kertas_button = tk.Button(root,width=37, pady=7, text = "KERTAS", command=lambda: Game("Kertas"), bg='#FFD700', fg = 'black', border=0, font=("Times New Roman", 12, 'bold')).place(x=300, y=250)

Game_button = tk.Button(root,width=20, pady=7, text="MULAI!", command=Game, font=("Times New Roman", 12, 'bold')).place(x=380, y=300)

result_var = tk.StringVar()
result_var.set("")
result_label = tk.Label(root, width=20, pady=7, textvariable = result_var ,bg= "#20B2AA", font=("Times New Roman", 14, 'bold')).place(x=360, y=350)


player_score_var = tk.StringVar()
player_score_var.set("Kamu: 0")
player_score_label = tk.Label(root, width=20, pady=7, textvariable = player_score_var, bg= "#20B2AA",font=("Times New Roman", 12, 'bold')).place(x=380, y=400)

rival_score_var = tk.StringVar()
rival_score_var.set("Lawan: 0")
rival_score_label = tk.Label(root,width=20, pady=7, textvariable = rival_score_var, bg= "#20B2AA", font=("Times New Roman", 12, 'bold')).place(x=380, y=430)


root.mainloop()
